# PHP配置

存放php扩展、php.ini配置