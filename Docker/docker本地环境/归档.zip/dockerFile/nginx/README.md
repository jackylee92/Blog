docker build -t dev/nginx:v1 .
